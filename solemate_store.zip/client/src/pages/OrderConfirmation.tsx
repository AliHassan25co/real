import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingCart, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";

interface OrderData {
  id: string;
  date: string;
  items: Array<{
    id: string;
    name: string;
    price: number;
    quantity: number;
    size: string;
  }>;
  total: number;
  customer: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
  };
}

export default function OrderConfirmation() {
  const [, navigate] = useLocation();
  const [orderData, setOrderData] = useState<OrderData | null>(null);

  useEffect(() => {
    const lastOrder = localStorage.getItem("lastOrder");
    if (lastOrder) {
      setOrderData(JSON.parse(lastOrder));
    }
  }, []);

  if (!orderData) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-black mb-4">Order Not Found</h1>
          <Button onClick={() => navigate("/")}>Back to Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_logo-5hapySowC5YNTgq88QNVvK.webp" 
              alt="SoleMate" 
              className="w-8 h-8"
            />
            <span className="text-xl font-bold text-accent">SoleMate</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/")} className="hover:text-accent transition-colors">Home</button>
            <button onClick={() => navigate("/shop")} className="hover:text-accent transition-colors">Shop</button>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors"
            >
              <ShoppingCart size={20} />
              <span>Cart</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Success Message */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <CheckCircle size={80} className="text-accent" />
            </div>
            <h1 className="text-5xl font-black mb-4">Order Confirmed!</h1>
            <p className="text-xl text-muted-foreground mb-2">Thank you for your purchase</p>
            <p className="text-muted-foreground">Your order has been successfully placed and will be shipped soon.</p>
          </div>

          {/* Order Details */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {/* Order Info */}
            <div className="lg:col-span-2">
              <div className="bg-card border border-border rounded-lg p-8 mb-8">
                <h2 className="text-2xl font-black mb-6">Order Details</h2>
                
                <div className="grid grid-cols-2 gap-6 mb-8 pb-8 border-b border-border">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Order Number</p>
                    <p className="font-bold text-lg">{orderData.id}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Order Date</p>
                    <p className="font-bold text-lg">{orderData.date}</p>
                  </div>
                </div>

                <h3 className="font-bold text-lg mb-4">Items Ordered</h3>
                <div className="space-y-4 mb-8 pb-8 border-b border-border">
                  {orderData.items.map((item) => (
                    <div key={item.id} className="flex justify-between items-start">
                      <div>
                        <p className="font-bold">{item.name}</p>
                        <p className="text-sm text-muted-foreground">Size: {item.size} × {item.quantity}</p>
                      </div>
                      <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>

                <h3 className="font-bold text-lg mb-4">Shipping To</h3>
                <div className="text-muted-foreground">
                  <p>{orderData.customer.firstName} {orderData.customer.lastName}</p>
                  <p>{orderData.customer.address}</p>
                  <p>{orderData.customer.city}, {orderData.customer.state} {orderData.customer.zipCode}</p>
                  <p className="mt-2">Email: {orderData.customer.email}</p>
                  <p>Phone: {orderData.customer.phone}</p>
                </div>
              </div>

              <div className="bg-card border border-border rounded-lg p-8">
                <h3 className="font-bold text-lg mb-4">What's Next?</h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold mt-1">✓</span>
                    <span>You'll receive a confirmation email shortly with tracking information</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold mt-1">✓</span>
                    <span>Your order will be shipped within 2-3 business days</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold mt-1">✓</span>
                    <span>You can track your shipment using the tracking number provided</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-card border border-border rounded-lg p-6 sticky top-24">
                <h3 className="font-bold text-lg mb-6">Order Summary</h3>
                
                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-bold">${(orderData.total / 1.1).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span className="font-bold">FREE</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tax (10%)</span>
                    <span className="font-bold">${(orderData.total - orderData.total / 1.1).toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex justify-between mb-6">
                  <span className="font-bold text-lg">Total</span>
                  <span className="text-2xl font-black text-accent">${orderData.total.toFixed(2)}</span>
                </div>

                <Button 
                  onClick={() => navigate("/shop")}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-6 text-lg font-bold mb-3"
                >
                  Continue Shopping
                </Button>

                <Button 
                  onClick={() => navigate("/")}
                  variant="outline"
                  className="w-full border-border hover:bg-secondary"
                >
                  Back to Home
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 mt-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About SoleMate</h4>
              <p className="text-muted-foreground text-sm">Your destination for premium sneakers and urban style.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">New Arrivals</a></li>
                <li><a href="#" className="hover:text-accent">Best Sellers</a></li>
                <li><a href="#" className="hover:text-accent">Sale</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Contact Us</a></li>
                <li><a href="#" className="hover:text-accent">Shipping Info</a></li>
                <li><a href="#" className="hover:text-accent">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Instagram</a></li>
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2026 SoleMate. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
