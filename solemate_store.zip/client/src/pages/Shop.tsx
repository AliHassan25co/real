import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingCart } from "lucide-react";
import { useState } from "react";

const PRODUCTS = [
  {
    id: "1",
    name: "Urban Runner Pro",
    price: 129.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Running",
    description: "Professional running shoe with advanced cushioning"
  },
  {
    id: "2",
    name: "Street Legend",
    price: 149.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Lifestyle",
    description: "Classic street style sneaker with premium materials"
  },
  {
    id: "3",
    name: "Electric Pulse",
    price: 139.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Performance",
    description: "High-performance athletic sneaker"
  },
  {
    id: "4",
    name: "Neon Vibe",
    price: 119.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Casual",
    description: "Casual everyday sneaker with vibrant design"
  }
];

export default function Shop() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState("featured");

  const categories = ["All", "Running", "Lifestyle", "Performance", "Casual"];
  
  let filteredProducts = PRODUCTS;
  if (selectedCategory !== "All") {
    filteredProducts = PRODUCTS.filter(p => p.category === selectedCategory);
  }

  if (sortBy === "price-low") {
    filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  } else if (sortBy === "price-high") {
    filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_logo-5hapySowC5YNTgq88QNVvK.webp" 
              alt="SoleMate" 
              className="w-8 h-8"
            />
            <span className="text-xl font-bold text-accent">SoleMate</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/")} className="hover:text-accent transition-colors">Home</button>
            <button onClick={() => navigate("/shop")} className="text-accent font-bold">Shop</button>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors"
            >
              <ShoppingCart size={20} />
              <span>Cart</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Page Header */}
      <section className="bg-card border-b border-border py-12">
        <div className="container">
          <h1 className="text-4xl font-black mb-2">Shop Collection</h1>
          <p className="text-muted-foreground">Discover our curated selection of premium sneakers</p>
        </div>
      </section>

      {/* Filters and Products */}
      <section className="py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar Filters */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-lg p-6 border border-border">
                <h3 className="font-bold text-lg mb-4">Categories</h3>
                <div className="space-y-2 mb-6">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`block w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        selectedCategory === cat
                          ? "bg-accent text-accent-foreground"
                          : "hover:bg-secondary"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                <h3 className="font-bold text-lg mb-4">Sort By</h3>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full bg-secondary border border-border rounded-lg px-4 py-2 text-foreground"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>

            {/* Products Grid */}
            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <div 
                    key={product.id}
                    className="group bg-card rounded-lg overflow-hidden border border-border hover:border-accent transition-colors"
                  >
                    <div 
                      className="relative overflow-hidden bg-secondary h-64 cursor-pointer"
                      onClick={() => navigate(`/product/${product.id}`)}
                    >
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <p className="text-accent text-sm mb-1">{product.category}</p>
                      <h3 
                        className="text-lg font-bold mb-2 cursor-pointer hover:text-accent transition-colors"
                        onClick={() => navigate(`/product/${product.id}`)}
                      >
                        {product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-4">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <p className="text-2xl font-black text-accent">${product.price}</p>
                        <Button 
                          onClick={() => navigate(`/product/${product.id}`)}
                          className="bg-accent hover:bg-accent/90 text-accent-foreground"
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About SoleMate</h4>
              <p className="text-muted-foreground text-sm">Your destination for premium sneakers and urban style.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">New Arrivals</a></li>
                <li><a href="#" className="hover:text-accent">Best Sellers</a></li>
                <li><a href="#" className="hover:text-accent">Sale</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Contact Us</a></li>
                <li><a href="#" className="hover:text-accent">Shipping Info</a></li>
                <li><a href="#" className="hover:text-accent">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Instagram</a></li>
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2026 SoleMate. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
