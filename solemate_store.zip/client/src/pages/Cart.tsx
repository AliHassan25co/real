import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingCart, Trash2, ArrowLeft } from "lucide-react";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

export default function Cart() {
  const [, navigate] = useLocation();
  const { items, removeFromCart, updateQuantity, getTotalPrice, getTotalItems } = useCart();

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error("Your cart is empty");
      return;
    }
    navigate("/checkout");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_logo-5hapySowC5YNTgq88QNVvK.webp" 
              alt="SoleMate" 
              className="w-8 h-8"
            />
            <span className="text-xl font-bold text-accent">SoleMate</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/")} className="hover:text-accent transition-colors">Home</button>
            <button onClick={() => navigate("/shop")} className="hover:text-accent transition-colors">Shop</button>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors"
            >
              <ShoppingCart size={20} />
              <span>Cart ({getTotalItems()})</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Page Header */}
      <section className="bg-card border-b border-border py-8">
        <div className="container">
          <button 
            onClick={() => navigate("/shop")}
            className="flex items-center gap-2 text-muted-foreground hover:text-accent transition-colors mb-4"
          >
            <ArrowLeft size={16} />
            Back to Shop
          </button>
          <h1 className="text-4xl font-black">Shopping Cart</h1>
        </div>
      </section>

      {/* Cart Content */}
      <section className="py-12">
        <div className="container">
          {items.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingCart size={64} className="mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-3xl font-black mb-4">Your cart is empty</h2>
              <p className="text-muted-foreground mb-8">Start shopping to add items to your cart</p>
              <Button 
                onClick={() => navigate("/shop")}
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg"
              >
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.id} className="bg-card border border-border rounded-lg p-6 flex gap-6">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-bold text-lg mb-1">{item.name}</h3>
                        <p className="text-muted-foreground text-sm mb-2">Size: {item.size}</p>
                        <p className="text-accent font-bold">${item.price}</p>
                      </div>
                      <div className="flex flex-col items-end justify-between">
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-destructive hover:text-destructive/80 transition-colors"
                        >
                          <Trash2 size={20} />
                        </button>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 border border-border rounded hover:bg-secondary transition-colors"
                          >
                            −
                          </button>
                          <span className="font-bold w-6 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 border border-border rounded hover:bg-secondary transition-colors"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-card border border-border rounded-lg p-6 sticky top-24">
                  <h3 className="font-bold text-lg mb-6">Order Summary</h3>
                  
                  <div className="space-y-3 mb-6 pb-6 border-b border-border">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-bold">${getTotalPrice().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Shipping</span>
                      <span className="font-bold">FREE</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tax</span>
                      <span className="font-bold">${(getTotalPrice() * 0.1).toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="flex justify-between mb-6">
                    <span className="font-bold text-lg">Total</span>
                    <span className="text-2xl font-black text-accent">${(getTotalPrice() * 1.1).toFixed(2)}</span>
                  </div>

                  <Button 
                    onClick={handleCheckout}
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-6 text-lg font-bold mb-3"
                  >
                    Proceed to Checkout
                  </Button>

                  <Button 
                    onClick={() => navigate("/shop")}
                    variant="outline"
                    className="w-full border-border hover:bg-secondary"
                  >
                    Continue Shopping
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About SoleMate</h4>
              <p className="text-muted-foreground text-sm">Your destination for premium sneakers and urban style.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">New Arrivals</a></li>
                <li><a href="#" className="hover:text-accent">Best Sellers</a></li>
                <li><a href="#" className="hover:text-accent">Sale</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Contact Us</a></li>
                <li><a href="#" className="hover:text-accent">Shipping Info</a></li>
                <li><a href="#" className="hover:text-accent">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Instagram</a></li>
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2026 SoleMate. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
