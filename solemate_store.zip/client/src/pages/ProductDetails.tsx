import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingCart, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";

const PRODUCTS = [
  {
    id: "1",
    name: "Urban Runner Pro",
    price: 129.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Running",
    description: "Professional running shoe with advanced cushioning",
    fullDescription: "Experience ultimate comfort with our Urban Runner Pro. Featuring advanced cushioning technology and breathable mesh, these shoes are perfect for daily runs and urban exploration."
  },
  {
    id: "2",
    name: "Street Legend",
    price: 149.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Lifestyle",
    description: "Classic street style sneaker with premium materials",
    fullDescription: "The Street Legend combines timeless design with premium materials. Perfect for any occasion, from casual outings to street culture events."
  },
  {
    id: "3",
    name: "Electric Pulse",
    price: 139.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Performance",
    description: "High-performance athletic sneaker",
    fullDescription: "Built for athletes and performance enthusiasts. The Electric Pulse delivers exceptional support and durability for intense activities."
  },
  {
    id: "4",
    name: "Neon Vibe",
    price: 119.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Casual",
    description: "Casual everyday sneaker with vibrant design",
    fullDescription: "Stand out with the Neon Vibe. Its vibrant design and comfortable fit make it the perfect choice for everyday wear."
  }
];

const SIZES = ["6", "7", "8", "9", "10", "11", "12", "13"];

export default function ProductDetails({ params }: { params: { id: string } }) {
  const [, navigate] = useLocation();
  const { addToCart } = useCart();
  const [selectedSize, setSelectedSize] = useState("");
  const [quantity, setQuantity] = useState(1);

  const product = PRODUCTS.find(p => p.id === params.id);

  if (!product) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-black mb-4">Product Not Found</h1>
          <Button onClick={() => navigate("/shop")}>Back to Shop</Button>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      toast.error("Please select a size");
      return;
    }
    
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity,
      image: product.image,
      size: selectedSize
    });
    
    toast.success(`${product.name} added to cart!`);
    setSelectedSize("");
    setQuantity(1);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_logo-5hapySowC5YNTgq88QNVvK.webp" 
              alt="SoleMate" 
              className="w-8 h-8"
            />
            <span className="text-xl font-bold text-accent">SoleMate</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/")} className="hover:text-accent transition-colors">Home</button>
            <button onClick={() => navigate("/shop")} className="hover:text-accent transition-colors">Shop</button>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors"
            >
              <ShoppingCart size={20} />
              <span>Cart</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="bg-card border-b border-border py-4">
        <div className="container">
          <button 
            onClick={() => navigate("/shop")}
            className="flex items-center gap-2 text-muted-foreground hover:text-accent transition-colors"
          >
            <ArrowLeft size={16} />
            Back to Shop
          </button>
        </div>
      </div>

      {/* Product Details */}
      <section className="py-12">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Image */}
            <div className="flex items-center justify-center bg-secondary rounded-lg overflow-hidden h-96 lg:h-full">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Details */}
            <div>
              <p className="text-accent text-sm font-bold mb-2">{product.category}</p>
              <h1 className="text-5xl font-black mb-4">{product.name}</h1>
              <p className="text-3xl font-black text-accent mb-6">${product.price}</p>
              
              <p className="text-muted-foreground mb-8 text-lg">{product.fullDescription}</p>

              {/* Size Selection */}
              <div className="mb-8">
                <h3 className="font-bold text-lg mb-4">Select Size</h3>
                <div className="grid grid-cols-4 gap-3">
                  {SIZES.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-3 rounded-lg border-2 font-bold transition-colors ${
                        selectedSize === size
                          ? "bg-accent text-accent-foreground border-accent"
                          : "border-border hover:border-accent"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div className="mb-8">
                <h3 className="font-bold text-lg mb-4">Quantity</h3>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 border border-border rounded-lg hover:bg-secondary transition-colors"
                  >
                    −
                  </button>
                  <span className="text-2xl font-bold w-8 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 border border-border rounded-lg hover:bg-secondary transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add to Cart */}
              <Button 
                onClick={handleAddToCart}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground py-6 text-lg font-bold flex items-center justify-center gap-2 mb-4"
              >
                <ShoppingCart size={24} />
                Add to Cart
              </Button>

              {/* Features */}
              <div className="bg-card border border-border rounded-lg p-6 space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-accent font-bold">✓</span>
                  <span>Free shipping on orders over $100</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-accent font-bold">✓</span>
                  <span>30-day return policy</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-accent font-bold">✓</span>
                  <span>Authentic sneakers guaranteed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About SoleMate</h4>
              <p className="text-muted-foreground text-sm">Your destination for premium sneakers and urban style.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">New Arrivals</a></li>
                <li><a href="#" className="hover:text-accent">Best Sellers</a></li>
                <li><a href="#" className="hover:text-accent">Sale</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Contact Us</a></li>
                <li><a href="#" className="hover:text-accent">Shipping Info</a></li>
                <li><a href="#" className="hover:text-accent">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Instagram</a></li>
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2026 SoleMate. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
