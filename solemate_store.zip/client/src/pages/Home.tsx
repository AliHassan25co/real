import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ShoppingCart, ArrowRight } from "lucide-react";

const FEATURED_PRODUCTS = [
  {
    id: "1",
    name: "Urban Runner Pro",
    price: 129.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Running"
  },
  {
    id: "2",
    name: "Street Legend",
    price: 149.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Lifestyle"
  },
  {
    id: "3",
    name: "Electric Pulse",
    price: 139.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp",
    category: "Performance"
  },
  {
    id: "4",
    name: "Neon Vibe",
    price: 119.99,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_2-kuowK3VwLJAGxGgFzBWH9v.webp",
    category: "Casual"
  }
];

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_logo-5hapySowC5YNTgq88QNVvK.webp" 
              alt="SoleMate" 
              className="w-8 h-8"
            />
            <span className="text-xl font-bold text-accent">SoleMate</span>
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/")} className="hover:text-accent transition-colors">Home</button>
            <button onClick={() => navigate("/shop")} className="hover:text-accent transition-colors">Shop</button>
            <button 
              onClick={() => navigate("/cart")}
              className="flex items-center gap-2 bg-accent text-accent-foreground px-4 py-2 rounded-lg hover:bg-accent/90 transition-colors"
            >
              <ShoppingCart size={20} />
              <span>Cart</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent z-10" />
        <img 
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663494949197/HPZT9Ba9tG5zWrWDALFAmQ/solemate_hero_1-iXNEjJYNGC8qQSvRuvsbDo.webp"
          alt="Hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="container relative z-20">
          <div className="max-w-2xl">
            <h1 className="text-6xl font-black mb-4 leading-tight">
              <span className="text-accent">Step Up</span>
              <br />
              Your Game
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Discover premium sneakers that define your style. From urban streets to performance tracks, find your perfect SoleMate.
            </p>
            <div className="flex gap-4">
              <Button 
                onClick={() => navigate("/shop")}
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg flex items-center gap-2"
              >
                Explore Collection <ArrowRight size={20} />
              </Button>
              <Button 
                variant="outline"
                className="border-accent text-accent hover:bg-accent/10 px-8 py-6 text-lg"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-card">
        <div className="container">
          <div className="mb-12">
            <h2 className="text-4xl font-black mb-2">Featured Kicks</h2>
            <p className="text-muted-foreground text-lg">Handpicked sneakers for the modern urbanite</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURED_PRODUCTS.map((product) => (
              <div 
                key={product.id}
                onClick={() => navigate(`/product/${product.id}`)}
                className="group cursor-pointer"
              >
                <div className="relative overflow-hidden rounded-lg mb-4 bg-secondary h-64">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <h3 className="text-lg font-bold mb-1">{product.name}</h3>
                <p className="text-accent text-sm mb-2">{product.category}</p>
                <p className="text-2xl font-black text-accent">${product.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-black text-accent-foreground">✓</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Premium Quality</h3>
              <p className="text-muted-foreground">Authentic sneakers from top brands worldwide</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-black text-accent-foreground">⚡</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Fast Shipping</h3>
              <p className="text-muted-foreground">Get your kicks delivered within 2-3 business days</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-black text-accent-foreground">🛡️</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Secure Checkout</h3>
              <p className="text-muted-foreground">Your payment information is always protected</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About SoleMate</h4>
              <p className="text-muted-foreground text-sm">Your destination for premium sneakers and urban style.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">New Arrivals</a></li>
                <li><a href="#" className="hover:text-accent">Best Sellers</a></li>
                <li><a href="#" className="hover:text-accent">Sale</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Contact Us</a></li>
                <li><a href="#" className="hover:text-accent">Shipping Info</a></li>
                <li><a href="#" className="hover:text-accent">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-accent">Instagram</a></li>
                <li><a href="#" className="hover:text-accent">Twitter</a></li>
                <li><a href="#" className="hover:text-accent">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
            <p>&copy; 2026 SoleMate. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
